h = Hombre.new
h.caminar
h.hablar

s = Sapo.new
s.saltar

a = Aguila.new
a.volar

p= Perro.new
p.volar